/* generated configuration header file - do not edit */
#ifndef BSP_MCU_DEVICE_PN_CFG_H_
#define BSP_MCU_DEVICE_PN_CFG_H_
#define BSP_MCU_R7FS7G27H3A01CFC
#define BSP_ROM_SIZE_BYTES (4194304)
#define BSP_RAM_SIZE_BYTES (655360)
#define BSP_DATA_FLASH_SIZE_BYTES (65536)
#define BSP_PACKAGE_LQFP
#define BSP_PACKAGE_PINS (176)
#endif /* BSP_MCU_DEVICE_PN_CFG_H_ */
