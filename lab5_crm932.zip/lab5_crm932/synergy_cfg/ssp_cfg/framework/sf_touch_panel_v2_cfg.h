/* generated configuration header file - do not edit */
#ifndef SF_TOUCH_PANEL_V2_CFG_H_
#define SF_TOUCH_PANEL_V2_CFG_H_
#define SF_TOUCH_PANEL_V2_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#define SF_TOUCH_PANEL_V2_CFG_THREAD_STACK_SIZE (512U)
#endif /* SF_TOUCH_PANEL_V2_CFG_H_ */
