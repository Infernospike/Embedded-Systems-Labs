/* generated configuration header file - do not edit */
#ifndef GX_USER_H_
#define GX_USER_H_
#if (SYNERGY_NOT_DEFINED)
#include "gx_src_user.h"
#endif
#define GX_USE_SYNERGY_DRW  (1)
#define GX_USE_SYNERGY_JPEG (1)
#define GX_SYNERGY_FONT_FORMAT_SUPPORT
#if (1)
#define GUIX_5_4_0_COMPATIBILITY
#endif
#endif /* GX_USER_H_ */
